import { test as baseTest } from "@playwright/test";
import LoginPage from "../pages/login.page";

const test = baseTest.extend<{
 
    login: LoginPage;
}>({
    login: async ({ page }, use) => {
        await use(new LoginPage(page));
    },
})

export default test;
export const expect = test.expect;