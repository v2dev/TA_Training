export default class ENV{
    public static BASE_URL = process.env.BASE_URL
}