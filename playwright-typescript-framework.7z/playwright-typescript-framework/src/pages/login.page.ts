import { Page } from "@playwright/test";


export default class LoginPage  {

    constructor(private page: Page) {}
    get acceptBtn(){
      return this.page.locator('button:has-text("Accept All Cookies")')
    };
    get confirmCheckBox(){
        return this.page.locator('input[name="checkbox"]')
      };
    get confirmBtn(){
        return this.page.locator('[aria-label="Welcome to T\\. Rowe Price"] button:has-text("Confirm")')
      };
    get functionalIntermediary(){
        return this.page.locator('text=Financial Intermediary').first()
    };
    get primaryCountry(){
        return this.page.locator('#site-selector-0 div:has-text("Italy")').nth(4);
    };
   async acceptCookies(){
    await this.acceptBtn.waitFor({"state":"visible"});
    await this.acceptBtn.click();
    await this.confirmBtn.click();
    await this.confirmCheckBox.waitFor({"state":"visible"});
    await this.confirmCheckBox.check();
    await this.confirmBtn.waitFor({"state":"visible"});
    await this.confirmBtn.click();
   };
   async clickFunctionalIntermediary(){
    await this.functionalIntermediary.waitFor({"state":"visible"});
    await this.functionalIntermediary.click();
    await this.primaryCountry.click();
   };
   async clickCountry(countryName:string){
    let country= this.page.locator("//a[contains(@aria-label,'" +countryName+ " English')]");
    await country.waitFor({"state":"visible"})
    await country.dblclick()
    //await country.
   };
}